<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Post;
use App\Comment;
use App\Video;

class OnemanypolyController extends Controller
{
    //
    public function onemanypoly()
    {
 
       $firstPost = Post::find(1);
       $commentsFirst = $firstPost->comments;

       $secondPost = Post::find(2);
       $commentsSecond = $secondPost->comments;

       $firstVideo = Video::find(1);
       $commentVideo = $firstVideo->comments;
       //dd($post->comments);	

       return view('index',compact('commentsFirst','commentsSecond','commentVideo'));
    }
}
