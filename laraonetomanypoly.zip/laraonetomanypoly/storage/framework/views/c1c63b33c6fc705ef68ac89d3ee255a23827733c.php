<html>
<head>
   
</head>
<style>
 
 
</style>
 
<h1> Laravel One to Many Polymorphic Example </h1>
 
<h3> First Post Comments </h3>
 
<?php $__currentLoopData = $commentsFirst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li> 
 
    <?php echo e($comments->comment_body); ?>  
 
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<h3> Second Post Comments </h3>

<?php $__currentLoopData = $commentsSecond; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li> 
 
    <?php echo e($comments->comment_body); ?>  
 
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<h3> First Video Comments </h3>

<?php $__currentLoopData = $commentVideo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li> 
 
    <?php echo e($comments->comment_body); ?>  
 
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html><?php /**PATH /Users/hardikparsania_mac/Desktop/web_demonuts/laraonetomanypoly/laraonetomanypoly/resources/views/index.blade.php ENDPATH**/ ?>