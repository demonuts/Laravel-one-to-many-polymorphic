<html>
<head>
   
</head>
<style>
 
 
</style>
 
<h1> Laravel One to Many Polymorphic Example </h1>
 
<h3> First Post Comments </h3>
 
@foreach ($commentsFirst as $comments)
<li> 
 
    {{ $comments->comment_body}}  
 
</li>
@endforeach

<h3> Second Post Comments </h3>

@foreach ($commentsSecond as $comments)
<li> 
 
    {{ $comments->comment_body}}  
 
</li>
@endforeach

<h3> First Video Comments </h3>

@foreach ($commentVideo as $comments)
<li> 
 
    {{ $comments->comment_body}}  
 
</li>
@endforeach

</body>
</html>